# Typhe

Wanted more **types** such as uint16, int16 and more? You can now!

# Types

**char**
**sint8**
**uint8**
**sint16**
**uint16**
**uint32**
**sint32**
**uint64**
**sint64**

## Additional Types

**mint** (Used for limiting integers)
**mstr** (Used for limiting strings)

# Requirements

setuptools >= 42
wheel
python >= 3.8